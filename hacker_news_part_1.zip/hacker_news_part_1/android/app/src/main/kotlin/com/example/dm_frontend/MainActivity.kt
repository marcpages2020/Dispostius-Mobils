package com.example.dm_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
