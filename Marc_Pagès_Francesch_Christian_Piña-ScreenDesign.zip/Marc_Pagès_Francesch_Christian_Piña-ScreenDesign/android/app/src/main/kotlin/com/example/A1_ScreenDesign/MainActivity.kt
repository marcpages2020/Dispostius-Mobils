package com.example.A1_ScreenDesign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
